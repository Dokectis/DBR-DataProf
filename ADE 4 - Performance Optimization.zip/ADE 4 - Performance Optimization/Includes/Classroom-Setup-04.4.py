# Databricks notebook source
# MAGIC %run ./Classroom-Setup-04-Common

# COMMAND ----------

DA = init_DA("4.4")